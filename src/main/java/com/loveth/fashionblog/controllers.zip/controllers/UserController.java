package com.loveth.fashionblog.controllers;

import com.loveth.fashionblog.dto.UserDto;
import com.loveth.fashionblog.models.User;
import com.loveth.fashionblog.services.UserServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.logging.ErrorManager;

//import static java.awt.Container.log;

@RestController
@RequestMapping("/users")
public class UserController {

    @Autowired
    private UserServices userServices;

    @PostMapping
    public User createUser(@RequestBody UserDto userdto) {
        return userServices.createUser(userdto);
    }

    // not working yet
    @GetMapping("/")
    @Cacheable(value = "userDetails")
    public List<User> getAllUsers(){
        return (List<User>) userServices.getAllUsers();
    }


//    @PostMapping("/login")
//    public User userLogin(@RequestBody LoginDto loginDto){
//       User user = userServices.loginUser();
//
//       if( user == null){
//
//           log.error("Invalid email/password");
//       }else {
//           log.info("User successfully logged in");
//       }
//       return user;
//    }

}
