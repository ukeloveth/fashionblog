package com.loveth.fashionblog.controllers;

import com.loveth.fashionblog.dto.PostDto;
import com.loveth.fashionblog.models.Post;
import com.loveth.fashionblog.services.PostServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/posts")
public class PostController {

    @Autowired
    private PostServices postService;

    @PostMapping("/{userId}")
    public Post createPost(@RequestBody PostDto postDto, @PathVariable("userId") Long id) {
        return postService.createPost(postDto, id);
    }

    @GetMapping
    public List<Post> getAllPosts() {
        return postService.getAllPosts();
    }
}
